# BBK OCR App (Flutter) — S25 Ultra Ready

**Features**
- Upload image or scan with camera.
- On-device OCR (Google ML Kit) with Arabic + English.
- Parses: Debit (12), IBAN (30 + checksum), SWIFT/BIC, Amount, Currency, Beneficiary Name/Bank, Purpose, Charges.
- Validations included.

## Build
1) Install Flutter (3.x) + Android Studio SDK.
2) In this folder:
```
flutter pub get
flutter run -d android
```
3) Build APK:
```
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`
